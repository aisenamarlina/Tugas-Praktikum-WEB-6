let angka1 = 10;
let angka2 = 5;
console.log("hasiln penjumlahan:", angka1 + angka2);
console.log("hasil perkalian:", angka1 * angka2);

// ubah warna background
function color(){
    document.body.style.backgroundColor="gray"
}
// Fungsi menampilkan bilangan ganjil 1-20
function tampilkanGanjil() {
    let hasil = "";
    for (let i = 1; i <= 20; i++) {
        if (i % 2 !== 0) {
            hasil += i + " ";
        }
    }
    document.getElementById("hasilGanjil").innerText = hasil;
}